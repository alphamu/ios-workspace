//
//  main.m
//  AccelerometerExample
//
//  Created by Ali Muzaffar on 12/06/13.
//  Copyright (c) 2013 Ali Muzaffar. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AccelerometerExampleAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AccelerometerExampleAppDelegate class]));
    }
}
