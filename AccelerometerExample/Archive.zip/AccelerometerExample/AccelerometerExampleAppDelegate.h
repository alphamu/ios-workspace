//
//  AccelerometerExampleAppDelegate.h
//  AccelerometerExample
//
//  Created by Ali Muzaffar on 12/06/13.
//  Copyright (c) 2013 Ali Muzaffar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccelerometerExampleAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
